package fr.eni.tpPotager.dal;

import org.springframework.data.repository.CrudRepository;

import fr.eni.tpPotager.bo.Carre;

public interface CarreDao extends CrudRepository<Carre, Integer>{

}
