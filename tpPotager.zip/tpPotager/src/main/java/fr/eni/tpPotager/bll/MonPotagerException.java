package fr.eni.tpPotager.bll;

public class MonPotagerException extends Exception {
	
	public MonPotagerException(String message) {
		super(message);
	}

}
