package fr.eni.tpPotager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpPotagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
