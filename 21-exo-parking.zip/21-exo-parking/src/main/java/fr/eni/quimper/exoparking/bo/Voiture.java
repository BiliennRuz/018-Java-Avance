package fr.eni.quimper.exoparking.bo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
public class Voiture {
	@Id
	@GeneratedValue
	private Integer idVoiture;
	private String type;
	private String couleur;
	private String immat;
	
	@ManyToOne
	private Parking parking;
	
	public Voiture(String type, String couleur, String immat) {
		super();
		this.type = type;
		this.couleur = couleur;
		this.immat = immat;
	}
	
}
