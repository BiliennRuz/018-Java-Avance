package fr.eni.quimper.exoparking.dal;

import org.springframework.data.repository.CrudRepository;

import fr.eni.quimper.exoparking.bo.Voiture;

public interface VoitureDAO extends CrudRepository<Voiture, Integer>{

}
