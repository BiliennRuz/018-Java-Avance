package fr.eni.quimper.exoparking.bo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
public class Parking {
	@Id
	@GeneratedValue
	private Integer idParking;
	private String lieu;
	private Integer nbPlace;
	
	public Parking(String lieu, Integer nbPlace) {
		super();
		this.lieu = lieu;
		this.nbPlace = nbPlace;
	}
	
}
