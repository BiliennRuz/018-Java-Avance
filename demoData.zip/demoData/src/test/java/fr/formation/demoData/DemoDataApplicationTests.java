package fr.formation.demoData;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
