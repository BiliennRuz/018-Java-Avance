package fr.eni.quimper.exo.Bureau.de.vote;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import fr.eni.quimper.exo.Bureau.de.vote.bo.Electeur;
import fr.eni.quimper.exo.Bureau.de.vote.dal.ElecteurDAO;

@SpringBootApplication
public class ExoBureauDeVoteApplication implements CommandLineRunner{
	@Autowired
	private ElecteurDAO dao;
	
	public static void main(String[] args) {
		SpringApplication.run(ExoBureauDeVoteApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		Electeur votant1 = new Electeur("AMPS", "Dominique", 44, "FR", "blanc");
		dao.save(votant1);
		System.out.println(votant1);
		Electeur votant2 = new Electeur("VEUX", "Jean", 18, "FR", "blanc");
		dao.save(votant2);
		System.out.println(votant2);
		
		dao.findAll().forEach(System.out::println);
		
	//	dao.deleteById(1);
		
	//	dao.findAll().forEach(System.out::println);
		
		
	}
	
}
