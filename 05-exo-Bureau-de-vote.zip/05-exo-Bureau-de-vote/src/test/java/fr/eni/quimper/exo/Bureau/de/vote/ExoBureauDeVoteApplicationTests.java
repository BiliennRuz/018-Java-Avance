package fr.eni.quimper.exo.Bureau.de.vote;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExoBureauDeVoteApplicationTests {

	@Test
	void contextLoads() {
	}

}
