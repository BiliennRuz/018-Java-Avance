package fr.formation.parking.bll;

public class ParkingException extends Exception {

	public ParkingException(String message) {
		super(message);
	}

}
