package fr.formation.potager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PotagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
