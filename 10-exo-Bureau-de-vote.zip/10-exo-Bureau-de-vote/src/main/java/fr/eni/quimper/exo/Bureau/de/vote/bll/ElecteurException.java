package fr.eni.quimper.exo.Bureau.de.vote.bll;

public class ElecteurException extends Exception {

	public ElecteurException(String message) {
		super(message);
	}
	
	
}
